Mochi Mood 1:1 美术替换版

已替换内容：
1. 页面改为 1:1 方形构图，适合 1024×1024 预览。
2. 顶部标题卡、情绪条、部位按钮、底部强度卡改为粉白玻璃软糖风格。
3. Canvas 角色参数改为更接近参考图的大头软糖宝宝比例。
4. 嘴巴和舌头 SVG 已替换：
   assets/export_sample/svg/mochiA_mouth_upper.svg
   assets/export_sample/svg/mochiA_mouth_lower.svg
   assets/export_sample/svg/mochiA_tongue.svg
5. 参考素材板已放入：
   assets/reference/mochi_mood_asset_board_reference.png

打开方式：
直接打开 index.html，或用本地服务器运行。

注意：
图中文字不要切图使用，页面里已经用真实 HTML 文本显示，避免 AI 图乱码。
