Mochi Mood 精简包

入口文件：
- index.html

本包只保留当前运行需要的文件：
- index.html
- styles.css
- src/main.js
- config/parts/tongue_main.part.json
- assets/export_sample/svg/mochiA_mouth_upper.svg
- assets/export_sample/svg/mochiA_mouth_lower.svg
- assets/export_sample/svg/mochiA_tongue.svg
- package.json

预览方式：
- 双击 index.html 可以看基础效果
- 或在本目录运行：npm run dev
- 浏览器打开：http://localhost:8000/

给别人替换素材时，优先替换这 3 个 SVG：
- assets/export_sample/svg/mochiA_mouth_upper.svg
- assets/export_sample/svg/mochiA_mouth_lower.svg
- assets/export_sample/svg/mochiA_tongue.svg

注意：
- 当前游戏运行时已经把这 3 个 SVG 的 path 同步进 src/main.js。
- 如果别人只替换 SVG 文件，视觉不会自动完全更新；把替换后的 SVG 发回后，需要再把 path 同步进 runtime。
